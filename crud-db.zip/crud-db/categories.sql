INSERT INTO `categories` (`id`, `name`, `created_at`, `updated_at`) VALUES (1, 'A', NULL, NULL);
INSERT INTO `categories` (`id`, `name`, `created_at`, `updated_at`) VALUES (2, 'B', NULL, NULL);
